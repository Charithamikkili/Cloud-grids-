#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>


int main(int argc, char *argv[]) {
    if (argc < 4) {
        printf("Usage: %s <m> <n> <tolerance>\n", argv[0]);
        return 1;
    }

    int m = atoi(argv[1]);
    int n = atoi(argv[2]);
    double tol = atof(argv[3]);

    double t[m + 2][n + 2], tnew[m + 2][n + 2], diff, difmax;

    // Initialising the temperature array with 11°C everywhere
    for (int i = 0; i <= m + 1; i++) {
        for (int j = 0; j <= n + 1; j++) {
            t[i][j] = 11.0;
        }
    }

    // Setting boundary conditions as per assignment requirements
    for (int i = 1; i <= m; i++) {
        t[i][0] = 47.0;      // Left boundary
        t[i][n + 1] = 100.0; // Right boundary
    }
    for (int j = 1; j <= n; j++) {
        t[0][j] = 15.0;      // Top boundary
        t[m + 1][j] = 60.0;  // Bottom boundary
    }


    difmax = 1000000.0;
    int iter = 0;

    // Start timing
    clock_t start_time = clock();

    while (difmax > tol) {
        iter++;
        difmax = 0.0;

        // Computing new temperatures
        for (int i = 1; i <= m; i++) {
            for (int j = 1; j <= n; j++) {
                tnew[i][j] = (t[i - 1][j] + t[i + 1][j] + t[i][j - 1] + t[i][j + 1]) / 4.0;
                diff = fabs(tnew[i][j] - t[i][j]);
                if (diff > difmax) {
                    difmax = diff;
                }
            }
        }

        // Updating the temperature grid
        for (int i = 1; i <= m; i++) {
            for (int j = 1; j <= n; j++) {
                t[i][j] = tnew[i][j];
            }
        }

        
    }

    // End timing
    clock_t end_time = clock();
    double total_time = ((double) (end_time - start_time)) / CLOCKS_PER_SEC;
    

    printf("Iterations: %d, Final Max Difference: %lf\n", iter, difmax);
    printf("Execution Time: %lf seconds\n", total_time);
 for (int i = 0; i <= m + 1; i++) {
       	for (int j = 0; j <= n + 1; j++) {
            printf("%3.6lf ", t[i][j]);
        }
        printf("\n");
}


    return 0;
}
