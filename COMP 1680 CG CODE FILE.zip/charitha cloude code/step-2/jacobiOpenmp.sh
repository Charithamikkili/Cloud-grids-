#!/bin/bash
#
#SBATCH --job-name=JacobiOpenmp.c
#SBATCH --output=./JacobiOpenmp
#
#SBATCH --cpus-per-task=8
#SBATCH --ntasks=1
#SBATCH --ntasks-per-node=1
#SBATCH --nodes=1
#SBATCH --partition=COMP1680-omp

 
./jacobiOpenmp 20 20 0.0001

