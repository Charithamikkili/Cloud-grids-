#!/bin/bash
#
#SBATCH --job-name=task3.c
#SBATCH --output=./task3
#
#SBATCH --cpus-per-task=8
#SBATCH --ntasks=1
#SBATCH --ntasks-per-node=1
#SBATCH --nodes=1
#SBATCH --partition=COMP1680-omp

 gcc -std=c99 -fopenmp task3.c -o task3

./task3 100 100 0.0001
./task3 150 150 0.0001
./task3 225 225 0.0001
./task3 275 275 0.0001

