#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <omp.h>

int main(int argc, char *argv[]) {
    int m, n;
    double tol;

    int i, j, iter;

    m = atoi(argv[1]);
    n = atoi(argv[2]);
    tol = atof(argv[3]);

    double t[m + 2][n + 2], tnew[m + 1][n + 1], diff, difmax;

     

    
    // Main loop

    iter;
    difmax = 1000000.0;

    // Timers for parallel region
    double start_time, end_time;
    double parallel_runtime;

    for (int num_threads = 1; num_threads <= 8; num_threads *= 2) {
        // Set the number of threads
        omp_set_num_threads(num_threads);

         // Initialising the temperature array with 11°C everywhere
        
        for (i = 0; i <= m + 1; i++) {
            for (j = 0; j <= n + 1; j++) {
                t[i][j] = 11.0;
            }
        }
	
	// Set boundary conditions
        for (i = 1; i <= m; i++) {
        t[i][0] = 47.0;     // Left boundary
        t[i][n + 1] = 100.0;  // Right boundary
    }

        for (j = 1; j <= n; j++) {
        t[0][j] = 15.0;      // Top boundary
        t[m + 1][j] = 60.0;  // Bottom boundary
    }
         // Start timing

        start_time = omp_get_wtime();
    //Jacobi iteration loop
        while (difmax > tol) {
            iter++;
            difmax = 0.0;
   

            // Computing new temperatures
            double local_difmax = 0.0;  // Declare a private variable for each thread
        
            for (i = 1; i <= m; i++) {
                for (j = 1; j <= n; j++) {
                    tnew[i][j] = (t[i - 1][j] + t[i + 1][j] + t[i][j - 1] + t[i][j + 1]) / 4.0;

                    // Work out the maximum difference between old and new temperatures
                    diff = fabs(tnew[i][j] - t[i][j]);
                    if (diff > local_difmax) {
                        local_difmax = diff;
                    }
                }
            }
    
                        difmax = local_difmax;

           // Updating the temperature grid
            #pragma omp parallel for shared(t, tnew) private(i, j)
            for (i = 1; i <= m; i++) {
                for (j = 1; j <= n; j++) {
                    t[i][j] = tnew[i][j];
                }
            }
	}
        
        //End timing
        end_time = omp_get_wtime();
        parallel_runtime = end_time - start_time;

        // Print results
       printf("\nFinal Results:\n");
       printf("Iterations: %d, Final Max Difference: %lf\n", iter, difmax);       printf("Number of Threads Used: %d\n", num_threads);
       printf("Parallel runtime: %lf seconds\n", parallel_runtime);
       printf("Temperature Array for 20x20\n");
                
            for (i = 0; i <= m + 1; i++) {
                for (j = 0; j <= n + 1; j++) {
                    printf("%3.6lf ", t[i][j]);
                }
                printf("\n");
            }
        

           }

    return 0;
}
