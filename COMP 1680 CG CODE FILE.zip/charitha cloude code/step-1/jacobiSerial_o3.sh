#!/bin/bash
#
#SBATCH --job-name=Jacobi2d.c
#SBATCH --output=./JacobiSerial_o3
#
#SBATCH --cpus-per-task=8
#SBATCH --ntasks=1
#SBATCH --ntasks-per-node=1
#SBATCH --nodes=1
#SBATCH --partition=COMP1680-omp

   gcc -std=c99 -o jacobi2d.c jacobiSerial_o3
./jacobiSerial_o3 100 100 0.0001
./jacobiSerial_o3 150 150 0.0001
./jacobiSerial_o3 225 225 0.0001
./jacobiSerial_o3 275 275 0.0001
