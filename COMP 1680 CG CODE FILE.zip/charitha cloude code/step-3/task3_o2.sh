#!/bin/bash
#
#SBATCH --job-name=task3.c
#SBATCH --output=./task3_o2
#
#SBATCH --cpus-per-task=8
#SBATCH --ntasks=1
#SBATCH --ntasks-per-node=1
#SBATCH --nodes=1
#SBATCH --partition=COMP1680-omp

 gcc -std=c99 -fopenmp task3.c -o task3_o2

./task3_o2 100 100 0.0001
./task3_o2 150 150 0.0001
./task3_o2 225 225 0.0001
./task3_o2 275 275 0.0001

