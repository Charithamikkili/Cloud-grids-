#!/bin/bash
#
#SBATCH --job-name=task3.c
#SBATCH --output=./task3_o1
#
#SBATCH --cpus-per-task=8
#SBATCH --ntasks=1
#SBATCH --ntasks-per-node=1
#SBATCH --nodes=1
#SBATCH --partition=COMP1680-omp

 gcc -std=c99 -fopenmp task3.c -o task3_o1

./task3_o1 100 100 0.0001
./task3_o1 150 150 0.0001
./task3_o1 225 225 0.0001
./task3_o1 275 275 0.0001

