#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <omp.h>

void runOptimizedSerial(int m, int n, double tol);

int main(int argc, char *argv[]) {
    if (argc != 4) {
        printf("Usage: %s <m> <n> <tolerance>\n", argv[0]);
        return 1;
    }

    int m, n, iter = 0;  // Declare and initialize 'iter'
    double tol;
int i, j;

    m = atoi(argv[1]);
    n = atoi(argv[2]);
    tol = atof(argv[3]);

    double t[m + 2][n + 2], tnew[m + 1][n + 1], diff, difmax;

   
    // Run the optimized serial version and measure its time
    double start_time_serial, end_time_serial;
    start_time_serial = omp_get_wtime();
    runOptimizedSerial(m, n, tol);
    end_time_serial = omp_get_wtime();
    double serial_runtime = end_time_serial - start_time_serial;

    printf("Optimized Serial Runtime: %lf seconds\n", serial_runtime);

        // Main loop
    iter;
    difmax = 1000000.0;

    // Timers for parallel region
    double start_time, end_time;
    double parallel_runtime;

    for (int num_threads = 2; num_threads <= 8; num_threads *= 2) {
        // Set the number of threads
        omp_set_num_threads(num_threads);

        // Reset temperature array
        #pragma omp parallel for shared(t) private(i, j)
        for (int i = 0; i <= m + 1; i++) {
            for (int j = 0; j <= n + 1; j++) {
                t[i][j] = 11.0;
            }
        }

        // Set boundary conditions
        for (int i = 1; i <= m; i++) {
            t[i][0] = 47.0;     // Left boundary
            t[i][n + 1] = 100.0;  // Right boundary
        }

        for (int j = 1; j <= n; j++) {
            t[0][j] = 15.0;      // Top boundary
            t[m + 1][j] = 60.0;  // Bottom boundary
        }

        start_time = omp_get_wtime();

        while (difmax > tol) {
            iter++;
            difmax = 0.0;

            // Update temperature for the next iteration in parallel
            double local_difmax = 0.0;  // Declare a private variable for each thread
            #pragma omp parallel for shared(t, tnew) private(i, j, diff) reduction(max : local_difmax)
            for (int i = 1; i <= m; i++) {
                for (int j = 1; j <= n; j++) {
                    tnew[i][j] = (t[i - 1][j] + t[i + 1][j] + t[i][j - 1] + t[i][j + 1]) / 4.0;

                    // Work out the maximum difference between old and new temperatures
                    diff = fabs(tnew[i][j] - t[i][j]);
                    if (diff > local_difmax) {
                        local_difmax = diff;
                    }
                }
            }

            // Update the global difmax after the reduction
            #pragma omp critical
            if (local_difmax > difmax) {
                difmax = local_difmax;
            }

            // Copy new to old temperatures
            #pragma omp parallel for shared(t, tnew) private(i, j)
            for (int i = 1; i <= m; i++) {
                for (int j = 1; j <= n; j++) {
                    t[i][j] = tnew[i][j];
                }
            }
        }

        end_time = omp_get_wtime();
        parallel_runtime = end_time - start_time;

        // Print results
       printf("Iterations: %d, Final Max Difference: %lf\n", iter, difmax);        
       printf("Number of Threads Used: %d\n", num_threads);
       printf("Parallel runtime: %lf seconds\n", parallel_runtime);
       

        // Calculate speedup and theoretical maximum speedup
        double speedup = serial_runtime / parallel_runtime;
        printf("Speedup: %lf\n", speedup);

        double theoretical_max_speedup = 1.0 / ((1.0 - 1.0 / num_threads) + 1.0 / num_threads);
        printf("Theoretical Maximum Speedup: %lf\n", theoretical_max_speedup);
	
	for (i = 0; i <= m + 1; i++) {
            for (j = 0; j <= n + 1; j++) {
              printf("%3.3lf ", t[i][j]); 
            }
            printf("\n");
        }

        // Reset iteration count and maximum difference for the next test
        iter = 0;
        difmax = 1000000.0;
    }

    return 0;
}

void runOptimizedSerial(int m, int n, double tol) {
    // Implementation of the optimized serial version
    // ...
}
